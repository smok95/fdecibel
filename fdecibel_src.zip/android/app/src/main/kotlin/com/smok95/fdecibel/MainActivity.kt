package com.smok95.fdecibel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
